# AWS
This is my AWS repository with sample Policy and Cloudformation templates.

1. Rotate-Security-Credentials-Policy.JSON
This policy document creates a Managed Policy that can be attached to an IAM user/group so that the user(s) can change password and/or access keys on a periodic basis. It is AWS best practice to rotate passwords and access keys on a period basis.

Note: Make sure to update the account number.
